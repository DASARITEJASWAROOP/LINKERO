from django.urls import path
from .import views
from django.conf.urls.static import static




urlpatterns = [
	path('',views.hem, name='jack'),
	path('about/', views.about, name='about'),
	path('contact/',views.contact,name='con'),
	path('signup/',views.signup,name='signup'),
	path('signin/',views.signin,name='signin'),
	path('logout/',views.logout,name='logout'),
	path('document/', views.document,name='document'),
	path('moviesweb/',views.moviesweb,name='moviesweb'),
	path('songsweb/',views.songsweb,name='songsweb'),
	path('onlinesongsweb/',views.onlinesongsweb,name='onlinesongsweb')




]
	# path('showe/', views.showe,  name='showe'),

	# path('normalupload/',views.normalupload,name='normalupload')



