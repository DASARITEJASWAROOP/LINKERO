from django.shortcuts import render, redirect
from django.contrib.auth.models import auth
from django.contrib import messages
from django.shortcuts import HttpResponseRedirect,reverse
from .models import *




from .forms import *
from django.http import HttpResponse

# Create your views here.
def hem(request):
    return render(request,'DEMPAPPL/hi.html')


def about(request):
    return render(request,'DEMPAPPL/about.html')

def contact(request):
    return render(request,'DEMPAPPL/contact.html')

def signup(request):

    if request.method == 'POST':
        username = request.POST['username']
        email = request.POST['email']
        password = request.POST['password']
        passwordcon = request.POST['passwordcon']

        if password == passwordcon:
                if User.objects.filter(username = username).exists():
                   messages.info(request,'users name already exist ')
                   print('already exist')
                   return redirect('signup')


                elif User.objects.filter(email=email).exists():
                    messages.info(request, 'email name already exist ')
                    print('already email exist')

                    return redirect('signup')

                else:
                      user = User.objects.create_user(username=username, password=password, email=email)
                      user.save()
                      return redirect('signin')
                      messages.info(request, 'REGISTRATION COMPLETED SUCUSSFULLY ')
        else:
            messages.info(request, 'PASSWORD NOT MATCH ')
            print('password not match')
            return redirect('signup')
        return redirect('/')
    else:
      return render(request,'DEMPAPPL/signup.html')

def signin(request):
    if request.method=='POST':
        username = request.POST['username']
        password = request.POST['password']

        user = auth.authenticate(username=username,password=password)
        if user is not None:
            auth.login(request,user)
            return redirect('/')
        else:
            messages.info(request,'invalid creditional')
            return redirect('signin')
    else:
        return render(request,'DEMPAPPL/signin.html')

def logout(request):
    auth.logout(request)
    return redirect('/')
#
# def document(request):
#
#
#     return render(request,'DEMPAPPL/document.html')




# def document(request):
#
#
#     if request.method == 'POST':
#
#
#
#
#         deals = dealForm(request.POST, request.FILES)
#         context['text'] = deals.objects.all()
#
#         if deals.is_valid():
#
#             images = dealForm('images')
#             descr = dealForm('descr')
#             links = dealForm('links')
#             context = {
#                 'images': images,
#                 'descr':descr,
#                 'links':links
#             }
#
#         else:
#
#             deals.save()
#
#             messages.info(request,'post upload successfully')
#
#             return redirect('document')
#
#
#     else:
#
#         form = dealForm()
#
#         # messages.info(request, 'post upload failed')
#
#     return render(request, 'DEMPAPPL/document.html')
#
#
# def showimages(request):
#     path = settings.MEDIA_ROOT
#     img_list = os.listdir(path)
#     context = {"images": img_list}
#     return render(request, 'DEMPAPPL/show.html', context)
def document(request):
    return render(request,'DEMPAPPL/document.html')

def moviesweb(request):
    return render(request,'DEMPAPPL/moviesweb.html')
def songsweb(request):
    return render(request,'DEMPAPPL/songsweb.html')
def onlinesongsweb(request):
    return render(request,'DEMPAPPL/onlinesonngsweb.html')
     


# def document(request):
#     if request.method == 'POST':
#         myfile = request.FILES['myfile']
#         fs = FileSystemStorage()
#         filename = fs.save(myfile.name,myfile)
#         url = fs.url(filename)
#         new_profile =profile(
#             descripition = request.POST['descripition '],
#             link = request.POST['link'],
#             image = url
#
#         )
#         new_profile.save()
#         all_uploads = profile.objects.all()
#
#         redirect('document',{'uploads' :  all_uploads}
# )
#     else:
#         return render(request,'DEMPAPPL/document.html')


# def list(request):
#     # Handle file upload
#     if request.method == 'POST':
#         form = DocumentForm(request.POST, request.FILES)
#         if form.is_valid():
#             newdoc = Document(docfile = request.FILES['docfile'])
#             newdoc.save()

#             # Redirect to the document list after POST
#             return HttpResponseRedirect(reverse('DEMOPROJECT.myapp.views.list'))
#     else:
#         form = DocumentForm() # A empty, unbound form

#     # Load documents for the list page
#     documents = Document.objects.all()

#     # Render list page with the documents and the form
#     return render(
#         'DEMPAPPL/list.html',
#         {'documents': documents, 'form': form},
#     )
