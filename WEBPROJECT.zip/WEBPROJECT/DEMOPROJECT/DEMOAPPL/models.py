from django.db import models
from django.contrib.auth.models import User



# Create your models here.
class signup(models.Model):

      username = models.CharField(max_length=40)
      email = models.EmailField(max_length=60)
      password = models.NullBooleanField(null=True)
      # passwordcon = models.NullBooleanField(null=True)
      picture = models.ImageField(upload_to='profile_images', blank=True)
      REQUIRED_FIELDS='User'
      USERNAME_FIELD=[]

def __str__(self):
    return self.user.username

# class deals(models.Model):
#       images = models.ImageField(upload_to='images/')
#       descr = models.CharField(max_length=1000)
#       links= models.CharField(max_length=100)
#
#
# def ___str__(self):
#       return self.images
#
# class Document(models.Model):
#     docfile = models.FileField(upload_to='documents/%Y/%m/%d')