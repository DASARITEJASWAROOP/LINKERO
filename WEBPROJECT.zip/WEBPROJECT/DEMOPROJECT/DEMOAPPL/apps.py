from django.apps import AppConfig


class DemoapplConfig(AppConfig):
    name = 'DEMOAPPL'
